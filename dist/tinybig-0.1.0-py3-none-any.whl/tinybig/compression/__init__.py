#Compression Functions TBD

from tinybig.module.base_transformation import (
    transformation as base_compression
)