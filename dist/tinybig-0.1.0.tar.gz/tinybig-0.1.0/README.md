# tinyBIG: A Toolkit of Reconciled Polynomial Network

![tinybig Logo](https://github.com/jwzhanggy/tinyBIG/blob/main/docs/assets/img/tinybig.png)
--------------------------------------------------------------------------------

version = 0.1.0