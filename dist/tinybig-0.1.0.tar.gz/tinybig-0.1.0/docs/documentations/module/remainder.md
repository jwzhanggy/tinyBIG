# remainder

::: tinybig.module.base_remainder.remainder