# fabrication

::: tinybig.module.base_fabrication.fabrication