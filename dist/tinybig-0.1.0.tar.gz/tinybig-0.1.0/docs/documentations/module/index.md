# tinybig.module

::: tinybig.module

---------------------------------------

## Data Transformation Function
* [transformation](transformation.md)

## Parameter Fabrication Function
* [fabrication](fabrication.md)

## Remainder Function
* [remainder](remainder.md)

## RPN Head
* [rpn_head](rpn_head.md)

## RPN Layer
* [rpn_layer](rpn_layer.md)
