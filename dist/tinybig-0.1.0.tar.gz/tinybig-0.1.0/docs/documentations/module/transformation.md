# transformation

::: tinybig.module.base_transformation.transformation