# mse
::: tinybig.metric.regression_metric.mse