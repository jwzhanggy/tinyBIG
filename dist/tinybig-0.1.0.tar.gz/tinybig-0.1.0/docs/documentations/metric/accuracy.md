# accuracy
::: tinybig.metric.classification_metric.accuracy