# tinybig.metric

::: tinybig.metric

---------------------------------------

## Base Metric
* [base_metric](metric.md)

## Classification Metrics
* [accuracy](accuracy.md)
* [f1](f1.md) 

## Regression Metrics
* [mse](mse.md)


