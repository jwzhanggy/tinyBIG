# naive_normal_expansion
::: tinybig.expansion.probabilistic_expansion.naive_normal_expansion