# trigonometric_expansion
::: tinybig.expansion.trigonometric_expansion.trigonometric_expansion