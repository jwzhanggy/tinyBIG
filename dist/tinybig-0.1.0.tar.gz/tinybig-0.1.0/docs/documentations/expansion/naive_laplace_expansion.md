# naive_laplace_expansion
::: tinybig.expansion.probabilistic_expansion.naive_laplace_expansion