# bspline_expansion
::: tinybig.expansion.recursive_expansion.bspline_expansion