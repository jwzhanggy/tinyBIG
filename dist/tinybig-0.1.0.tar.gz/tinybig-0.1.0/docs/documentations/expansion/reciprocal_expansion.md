# reciprocal_expansion
::: tinybig.expansion.basic_expansion.reciprocal_expansion