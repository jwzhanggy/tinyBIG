# hyperbolic_expansion
::: tinybig.expansion.trigonometric_expansion.hyperbolic_expansion