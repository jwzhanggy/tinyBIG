# fourier_expansion
::: tinybig.expansion.polynomial_expansion.fourier_expansion