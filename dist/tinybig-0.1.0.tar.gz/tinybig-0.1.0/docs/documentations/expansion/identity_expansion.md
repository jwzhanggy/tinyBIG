# identity_expansion
::: tinybig.expansion.basic_expansion.identity_expansion