# arc_hyperbolic_expansion
::: tinybig.expansion.trigonometric_expansion.arc_hyperbolic_expansion