# gaussian_rbf_expansion
::: tinybig.expansion.rbf_expansion.gaussian_rbf_expansion