# extended_expansion
::: tinybig.expansion.extended_expansion.extended_expansion