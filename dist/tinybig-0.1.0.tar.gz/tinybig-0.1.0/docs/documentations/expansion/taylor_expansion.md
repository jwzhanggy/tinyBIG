# taylor_expansion
::: tinybig.expansion.polynomial_expansion.taylor_expansion