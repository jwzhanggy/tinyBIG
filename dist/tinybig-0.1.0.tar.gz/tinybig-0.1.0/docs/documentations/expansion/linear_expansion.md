# linear_expansion
::: tinybig.expansion.basic_expansion.linear_expansion