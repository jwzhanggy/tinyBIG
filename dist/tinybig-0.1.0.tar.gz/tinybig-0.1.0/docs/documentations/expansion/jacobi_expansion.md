# jacobi_expansion
::: tinybig.expansion.recursive_expansion.jacobi_expansion