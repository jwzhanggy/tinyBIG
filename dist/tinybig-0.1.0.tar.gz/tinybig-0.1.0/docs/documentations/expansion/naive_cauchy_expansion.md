# naive_cauchy_expansion
::: tinybig.expansion.probabilistic_expansion.naive_cauchy_expansion