# combinatorial_expansion
::: tinybig.expansion.combinatorial_expansion.combinatorial_expansion