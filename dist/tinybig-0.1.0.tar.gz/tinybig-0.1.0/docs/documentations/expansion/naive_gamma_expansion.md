# naive_gamma_expansion
::: tinybig.expansion.probabilistic_expansion.naive_gamma_expansion