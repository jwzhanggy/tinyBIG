# chebyshev_expansion
::: tinybig.expansion.recursive_expansion.chebyshev_expansion