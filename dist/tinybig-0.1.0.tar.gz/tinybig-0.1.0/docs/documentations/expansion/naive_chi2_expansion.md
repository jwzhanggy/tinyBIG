# naive_chi2_expansion
::: tinybig.expansion.probabilistic_expansion.naive_chi2_expansion