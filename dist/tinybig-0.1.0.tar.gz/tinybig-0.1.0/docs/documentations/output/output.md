# result
::: tinybig.output.base_output.output