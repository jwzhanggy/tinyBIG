# prediction
::: tinybig.output.prediction