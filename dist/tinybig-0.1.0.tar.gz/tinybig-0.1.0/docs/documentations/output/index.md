# tinybig.output

::: tinybig.output

---------------------------------------

## Base Output
* [result](output.md)

## Prediction Output
* [prediction_output](prediction.md)