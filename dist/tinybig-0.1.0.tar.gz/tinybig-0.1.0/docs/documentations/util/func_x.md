# func_x

::: tinybig.util.util.func_x