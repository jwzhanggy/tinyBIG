# process_num_alloc_configs

::: tinybig.util.util.process_num_alloc_configs