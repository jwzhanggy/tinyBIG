# register_function_parameters

::: tinybig.util.util.register_function_parameters