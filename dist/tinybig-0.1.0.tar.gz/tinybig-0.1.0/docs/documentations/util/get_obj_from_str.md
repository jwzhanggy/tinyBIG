# get_obj_from_str

::: tinybig.util.util.get_obj_from_str