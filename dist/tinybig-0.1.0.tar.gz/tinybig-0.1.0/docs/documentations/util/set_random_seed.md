# set_random_seed

::: tinybig.util.util.set_random_seed