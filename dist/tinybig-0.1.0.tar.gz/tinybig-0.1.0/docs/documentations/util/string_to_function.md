# string_to_function

::: tinybig.util.util.string_to_function