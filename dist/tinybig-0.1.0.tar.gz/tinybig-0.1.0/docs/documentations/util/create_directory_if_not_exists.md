# create_directory_if_not_exists

::: tinybig.util.util.create_directory_if_not_exists