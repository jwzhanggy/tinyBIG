# tinybig.config

::: tinybig.config

---------------------------------------
## Base Config
* [config](config.md)

## RPN Config
* [rpn_config](rpn_config.md)
