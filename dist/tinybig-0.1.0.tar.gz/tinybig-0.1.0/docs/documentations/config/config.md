# config

::: tinybig.config.base_config.config