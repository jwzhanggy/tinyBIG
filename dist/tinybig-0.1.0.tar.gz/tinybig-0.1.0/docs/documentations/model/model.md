# model

::: tinybig.model.base_model.model