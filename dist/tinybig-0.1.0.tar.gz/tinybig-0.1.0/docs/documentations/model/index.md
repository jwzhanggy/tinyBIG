# tinybig.model

::: tinybig.model

---------------------------------------

## Base Model
* [model](model.md)

## RPN Model
* [rpn](rpn.md)
