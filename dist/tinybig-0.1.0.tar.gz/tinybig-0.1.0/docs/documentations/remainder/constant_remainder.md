# constant_remainder
::: tinybig.remainder.basic_remainder.constant_remainder