# one_remainder
::: tinybig.remainder.basic_remainder.one_remainder