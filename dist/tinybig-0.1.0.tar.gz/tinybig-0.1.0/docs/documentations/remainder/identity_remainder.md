# identity_remainder
::: tinybig.remainder.basic_remainder.identity_remainder