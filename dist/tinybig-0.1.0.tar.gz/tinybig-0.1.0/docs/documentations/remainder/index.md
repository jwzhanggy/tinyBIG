# tinybig.remainder

::: tinybig.remainder

---------------------------------------
## Basic Remainders
* [constant_remainder](constant_remainder.md)
* [zero_remainder](zero_remainder.md)
* [one_remainder](one_remainder.md)
* [identity_remainder](identity_remainder.md)
* [linear_remainder](linear_remainder.md)

## Expansion Remainder
* [bspline_remainder](bspline_remainder.md)
