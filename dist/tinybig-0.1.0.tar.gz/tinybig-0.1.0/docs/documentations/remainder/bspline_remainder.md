# bspline_remainder
::: tinybig.remainder.expansion_remainder.bspline_remainder