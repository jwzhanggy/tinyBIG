# linear_remainder
::: tinybig.remainder.basic_remainder.linear_remainder