# elementary_function
::: tinybig.data.function_dataloader.elementary_function