# diabetes
::: tinybig.data.tabular_dataloader.diabetes