# mnist
::: tinybig.data.vision_dataloader.mnist