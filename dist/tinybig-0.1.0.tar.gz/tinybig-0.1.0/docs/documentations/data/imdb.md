# imdb
::: tinybig.data.text_dataloader_torchtext.imdb