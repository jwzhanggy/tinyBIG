# imagenet
::: tinybig.data.vision_dataloader.imagenet