# cifar10
::: tinybig.data.vision_dataloader.cifar10