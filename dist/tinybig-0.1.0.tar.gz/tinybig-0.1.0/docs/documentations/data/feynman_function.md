# feynman_function
::: tinybig.data.feynman_dataloader.feynman_function