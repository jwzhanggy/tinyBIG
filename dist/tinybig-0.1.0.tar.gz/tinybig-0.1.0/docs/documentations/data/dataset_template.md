# dataset_template
::: tinybig.data.base_data.dataset_template